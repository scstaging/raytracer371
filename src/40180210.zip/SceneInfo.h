#pragma once

#include "Geometry.h"
#include "Light.h"
#include "Output.h"
#include <iostream>
#include "json.hpp"
#include "simpleppm.h"
#include <Eigen/Core>
#include <Eigen/Dense>
#include <sstream>

class SceneInfo {

public:
	// Constructor
	SceneInfo(const nlohmann::json& o);

	// Scene Properties
	Geometry* geometry;
	Light* light;
	Output* output;
	nlohmann::json jsonObj;

	// Parse Scene
	void parseAll();
	void parseGeometries();
	void parseLights();
	void parseOutput();

};